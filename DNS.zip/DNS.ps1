
Configuration DNSServerConfiguration
{  
  Node "localhost"
  {

    # Configure the LCM
    LocalConfigurationManager
    {
      ConfigurationMode = "ApplyOnly"
    }        

    WindowsFeature DNS
    {
      Name = "DNS"
      Ensure = "Present"
    }

    Script DNSConfig{
          #vars

        SetScript = {
        param(
            $AzureDNSIp = '168.63.129.16',
            $onPremIp = ('8.8.8.8','8.8.4.4')
        )
        # quasi idempotent script
        Add-DnsServerForwarder -IPAddress  $AzureDNSIp  -PassThru
        if($null -eq (Get-DnsServerZone -Name nav.no -ErrorAction SilentlyContinue))
            {
            Add-DnsServerConditionalForwarderZone -Name "nav.no" -MasterServers $onPremIp
            }
            else
                {
                Set-DnsServerConditionalForwarderZone -Name "nav.no" -MasterServers $onPremIp
                }
        }
        
        TestScript = {
             $false # always run for POC purposes
        }    
        
        GetScript = {
        # some kind of schema-spesific hashtable is returned here for unknown reasons
        }
        DependsOn = "[WindowsFeature]DNS"
        }
    }
    }

DNSServerConfiguration -OutputPath "C:\DscConfiguration"

Start-DscConfiguration -Wait -Verbose -Path "C:\DscConfiguration" -Force